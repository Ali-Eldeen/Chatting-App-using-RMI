package Operation;

import java.rmi.RemoteException;
import java.rmi.Remote;
/**
 *
 * @author ahmed
 */
public interface Operation extends Remote {
    public int sum(int x,int y)throws RemoteException;
    public int sub(int x,int y)throws RemoteException;
    public int mul(int x,int y)throws RemoteException;
    public int div(int x,int y)throws RemoteException;

}
