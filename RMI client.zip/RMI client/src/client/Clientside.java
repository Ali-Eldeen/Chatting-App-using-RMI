package client;

import Operation.Operation;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Clientside {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            Operation p = (Operation) Naming.lookup("rmi://127.0.0.1:12345/calc");
            System.out.println("Enter the first number");
            int x = sc.nextInt();
            System.out.println("Enter the second number");
            int y = sc.nextInt();
            System.out.println("Enter the Operation");
            String z = sc.next();

            if (z.equals("+")) {
                int r = p.sum(x, y);
                System.out.println(r);
            } else if (z.equals("-")) {
                int r = p.sub(x, y);
                System.out.println(r);
            }
            else if (z.equals("/")) {
                int r = p.div(x, y);
                System.out.println(r);
            }
            else if (z.equals("*")) {
                int r = p.mul(x, y);
                System.out.println(r);
            }
        } catch (MalformedURLException e) {
            System.out.println("Malformed URL: " + e.getMessage());
        } catch (RemoteException e) {
            System.out.println("Error invoking remote method: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Invalid input: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
