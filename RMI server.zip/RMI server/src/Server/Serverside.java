package Server;

import Server.Calculator;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Serverside {

    public static void main(String[] args) {
        try {
            System.out.println("Waiting for Connection");
            Registry r = LocateRegistry.createRegistry(12345);
            System.out.println("RMI Connection started successfully.");
            Calculator calculator=new Calculator();
            r.rebind("calc", calculator);
        } catch (Exception e) {
            System.out.println("Error starting RMI Connection: " + e.getMessage());
        }
    }
}
